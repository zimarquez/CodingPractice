Linux Monitor V1.0
Ismael Marquez
03/21/19

Note:
The application can only be run in a linux environment due to the psutil library only supporting linux environments

Steps to launch:
1) Move the "Linux_Monitor.py" and "graphics.py" files to the same directory
2) Open "Linux_Monitor.py" in your IDE of choice (Spyder was used for development)
3) Run the file

Known Issues:
1) The GUI flashes noticeably due to its update rate. Default rate is set at 0.5 seconds.